// console.log(`Hello`);
// console.log(`This is JavaScript Console!`);
//This is a comment
/* 
multiline comment 
*/
// window.alert('This is an alert!');
// window.alert('Please enter a valid password!');
// document.getElementById("myH1").textContent = `Hello`;
// document.getElementById("myP").textContent = `How are you?`;


/*
Three options:
var: Declares a variable ( local and global variables, depending on the execution context), 
     optionally initializing it to a value.
let: Declares a block-scoped, local variable, optionally initializing it to a value.
const: Declares a block-scoped, read-only named constant.

variable declaration
variable initialization
*/

var x;
//This syntax can be used to declare both 
//local and global variables, depending on the execution context.

x = 44;
console.log(x);

let y;
//This syntax can be used to declare a block-scope local variable
y = 56;
console.log(y);
/*
Scope: The main difference between var and let is that var is 
function-scoped, while let is block-scoped. 
This means that a var variable is visible to the whole function 
in which it is declared, while a let variable is only visible 
within the block in which it is declared.
*/
console.log(`The value of x is ${x}, and value of y is ${y}`);
/*
Variable Naming conventions:
Variable names must begin with a letter, $, or _
Variable names can only contain letters, numbers, $, and _
Variable names are case-sensitive
Avoid keywords
*/

/*
Global scope: When you declare a variable outside of any function, it is called a global variable
if (true) {
  var x = 5;
}
console.log(x);  // x is 5
Block statement scope
if (true) {
  let y = 5;
}
console.log(y);  // ReferenceError: y is not defined

*/
// if (true) {
//     var x = 5;
//   }
// console.log(`The value of var x is ${x}`);  // x is 5

// if (true) {
//     let y = 5;
//   }
// console.log(`The value of let y is ${y}`);  // ReferenceError: y is not defined
  
// //Evaluating variables
// var a;
// console.log('The value of a is ' + a); // The value of a is undefined
// a = 3;

// console.log('The value of b is ' + b); // The value of b is undefined
// var b;
// ???? What is happening here???

/*
Another unusual thing about variables in JavaScript is that 
you can refer to a variable declared later, without getting 
an exception.

This concept is known as hoisting. 
Variables in JavaScript are, in a sense, "hoisted" (or "lifted")
to the top of the function or statement. 
However, variables that are hoisted return a value 
of undefined. So even if you declare and initialize after you use or refer to this variable, it still returns undefined.

*/
// console.log('The value of c is ' + c); // Uncaught ReferenceError: c is not defined

// let d;
// console.log('The value of d is ' + d); // The value of x is undefined

// console.log('The value of e is ' + e); // Uncaught ReferenceError: y is not defined
// let e;
/*
In ECMAScript 2015, 
let and const are hoisted but not initialized. 
console.log(x); // ReferenceError
let x = 3;

Do you notice that the error does not say name is not defined?
That's because the interpreter is "aware" of a 'e' variable 
because the variable is hoisted.

"Cannot access 'e' before initialization" occurs because 
variables declared with let do not have a default value when 
hoisted. As we saw in var, the variables have a default value 
of undefined until the line where the 
declaration/initialization is executed. 
But with let, the variables are uninitialized.
*/

/*
  Types of data:
  Boolean. true and false.
  null. A special keyword denoting a null value. (Because JavaScript is case-sensitive, null is not the same as Null, NULL, or any other variant.)
  undefined. A top-level property whose value is not defined.
  Number. An integer or floating point number.
  BigInt. An integer with arbitrary precision.
  String. A sequence of characters that represent a text value. For example: "Howdy"
  Symbol (new in ECMAScript 2015). A data type whose instances are unique and immutable.
  and Object
*/
// var a = true;
// console.log(a);
// let b = null;
// console.log(b);
// let c = Null;
// console.log(c); //error

//combining strings
var firstName = 'John';
var lastName = 'Smith';
var fullName = firstName + lastName;
console.log(fullName);

//combining numbers and strings
var numOfVisits = 101;
var message = 'You have visited this site ' + numOfVisits + ' times.';
console.log(message);

var numOfShoes = '2';
var numOfSocks = 4;
var totalItems = Number(numOfShoes) + numOfSocks;
console.log(totalItems);


//augmented operators n js
var score = 0;
score = score + 100;
console.log(score);

let score1 = 0;
score1++;
console.log(score1);

// const score2 = 0;
// score2++; //TypeError: Attempted to assign to readonly property.
// console.log(score2);

/*
Declaring an array
var days = ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];
OR
var days = new Array('Mon', 'Tues', 'Wed');
You can store any mix of values in an array.
var prefs = [1, 223, 'https://www.utsc.utoronto.ca/home/', false];
Accessing elements:  prefs[2]
Adding an element: prefs.push(‘Hello World’);
Deleting the last element: prefs.pop();
Checking for array:
console.log(Array.isArray(prefs));
Finding the index
console.log(prefs.indexOf(223));
*/
// var days = ['Mon', 'Tues', 'Wed', 'Thurs', 'Fri', 'Sat', 'Sun'];
// console.log(days);

// var prefs = [1, 223, 'https://www.utsc.utoronto.ca/home/', false];
// console.log(prefs[0])

// prefs.push(`Hello World`);
// console.log(prefs);

// prefs.pop();
// console.log(prefs);

// console.log(Array.isArray(prefs));
// console.log(prefs.indexOf(223));

// var p =[0, 1, 2, 3];
// console.log(p.length);

//Elements to insert at the start of the array.
// p.unshift(4, 5);
// console.log(p);

//Removes the first element from an array and returns it.
// p.shift();
// console.log(p);

/*
You can conceptualize many of the elements of the JavaScript
 language, as well as elements of a web page, as objects. 
Example of Objects in JavaScript:
a browser window, a document, a string, a number, and a date

*/

// Defining an object:
const student = {
 firstName: 'John',
 lastname: 'Doe',
 age: 30,
 courses: ['A48', 'B20', 'C43'],
 address: {
   street: 'Main st',
   city: 'Toronto',
   province: 'Ontario'
 }
}
// Accessing an object:
console.log(student);
console.log(student.firstName);
student.email = 'student@mail.utoronto';
console.log(student);

//arrays of objects
const students = [
    {
      id: 1,
      classes: 'CSCB20',
      grade: 78
    },
    {
      id: 2,
      classes: 'CSCA48',
      grade: 90
    },
    {
      id: 3,
      classes: 'CSCA08',
      grade: 91
    }
  ];
console.log(students[0]);
console.log(students[0].classes);
  
/*
So far you’ve learned about some of JavaScript’s basic 
building blocks. 
But simply creating a variable and storing a string or number
in it doesn’t accomplish much.
And building an array with a long list of items won’t be very
 useful unless there’s an easy way to work your way through 
 the items in the array. 
 In this chapter, you’ll learn how to make your programs 
 react intelligently and work more efficiently by using 
 conditional statements, loops, and functions.
*/

// == or ===
console.log('2' == 2);
console.log('2' === 2);
console.log('2' === '2');


//If else - Friday night planner

// var fridayCash = prompt('How much money can you spend?', '');
// if (fridayCash >= 50) {
//   alert('You should go out to a dinner and a movie.');
// } else if (fridayCash >= 35) {
//   alert('You should go out to a fine meal.');
// } else if (fridayCash >= 12) {
//   alert('You should go see a movie.');
// } else {
//   alert('Looks like you will be watching TV.');
// }

//A switch statement allows a program to evaluate an 
//expression and attempt to match the expression's value 
//to a case label. If a match is found, the program executes 
//the associated statement.

// var fruitType = prompt('enter a fruit', '');
// switch (fruitType) {
//   case 'Oranges':
//     console.log('Oranges are $0.59 a pound.');
//     break;
//   case 'Apples':
//     console.log('Apples are $0.32 a pound.');
//     break;
//   case 'Bananas':
//     console.log('Bananas are $0.48 a pound.');
//     break;
//   default:
//     console.log(`Sorry, we are out of ${fruitType}.`);
// }
// console.log("Is there anything else you'd like?");


//while loops
var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
var counter = 1;
     while (counter < days.length) {
       document.write(days[counter] + ', ');
       counter++;
 }

 //for loop
 var days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
     for (var i=0; i<days.length; i++) {
         document.write(days[i] + ', ');
}

//functions

//Program to print today’s date
function printToday() {
      var today = new Date();
      document.write(today.toDateString());
}
//Run it by calling the function
printToday();

/*
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/this
This refers to the object that executing the current function
If function is part of an object → method //this refers 
to that object itself
If regular function → global object that’s window

*/

// In web browsers, the window object is also the global object:
console.log(this === window); // true

a = 37;
console.log(window.a); // 37

this.b = "MDN";
console.log(window.b)  // "MDN"
console.log(b)         // "MDN"

//function and function expressions
function square1(number) {
    return number * number;
  }
console.log(square1(4));

//While the function declaration above is syntactically 
//a statement, functions can also be created by a function 
//expression.

//Such a function can be anonymous; it does not have to have
// a name. For example, the function square could have been 
//defined as:


const square = function(number) { return number * number }
var x = square(4) // x gets the value 16
console.log(x);
  
//However, a name can be provided with a function expression. 
//Providing a name allows the function to refer to itself, 
//and also makes it easier to identify the function in a 
//debugger's stack traces:
const factorial = function fac(n) { return n < 2 ? 1 : n * fac(n - 1) }
console.log(factorial(3))


//Refer to slides for error handling
//bugs are one of the things that make our work as programmers interesting.
//A try / catch block is basically used to handle errors in JavaScript. 
//You use this when you don't want an error in your script to break your code.
//While this might look like something you can easily do with an if statement,
// try/catch gives you a lot of benefits beyond what an if/else statement can do, some of which you will see below.
//A try statement lets you test a block of code for errors.
//A catch statement lets you handle that error. For example:

/*
This is basically how a try/catch is constructed. 
You put your code in the try block, and immediately if there is an error, 
JavaScript gives the catch statement control and it just does whatever you say.
 In this case, it alerts you to the error.
*/

// let data=prompt("name");
// try{ 
//     if(data==="") 
//         throw new Error("data is empty"); 
//     else 
//         alert(`Hi ${data} how do you do today`); 
//     } 
// catch(e){ 
//         alert(e);
//     } 
// finally { 
//         alert("welcome to the try catch article");
// }

/*
One of the benefits of try/catch is its ability to display your own 
custom-created error. This is called (throw error).

In situations where you don't want this ugly thing that JavaScript displays, 
you can throw your error (an exception) with the use of the throw statement. 
This error can be a string, boolean, or object. 
And if there is an error, the catch statement will display the error you throw.
*/

// let num =prompt("insert a number greater than 30 but less than 40");
// try { 
//   if(isNaN(num)) throw "Not a number!"; 
//   else if (num>40) throw "It's not less than 40";
//   else if (num <= 30) throw "It's Greater than 30"; 
// }
// catch(e){
//   alert(e) 
// }

/*
The Document Object Model (DOM) is a programming interface for web documents. 
It represents the page so that programs can change the document structure, 
style, and content. The DOM represents the document as nodes and objects; 
that way, programming languages can interact with the page.

What is DOM?
An application programming interface (API) for manipulating HTML documents.
What does it represent?
represents an HTML document as a tree of nodes.
Why do we need DOM?
provides functions that allow you to add, remove, and modify parts of the document effectively.
DOM also provides cross-platform and language-independent ways of manipulating HTML and XML documents


selecting elements:
getElementById() – select an element by id.
getElementsByName() – select elements by name.
getElementsByTagName()  – select elements by a tag name.
getElementsByClassName() – select elements by one or more class names.
querySelector()  – select elements by CSS selectors.

manipulating elements
createElement() – create a new element.
createTextNode(data)- creats a new text node
appendChild()  – append a node to a list of child nodes of a specified parent node.
textContent – get and set the text content of a node.
innerHTML – get and set the HTML content of an element.
insertBefore() – insert a new node before an existing node as a child node of a specified parent node.
insertAfter() helper function – insert a new node after an existing node as a child node of a specified parent node.
append() – insert a node after the last child node of a parent node.
prepend() – insert a node before the first child node of a parent node.
insertAdjacentHTML() – parse a text as HTML and insert the resulting nodes into the document at a specified position.

events:
Events are actions or occurrences that happen in the system
you are programming, which the system tells you about so your code can react 
to them.
 */

// document.body.onload = addElement;

// function addElement () {
//   // create a new div element
//   const newDiv = document.createElement("div");

//   // and give it some content
//   const newContent = document.createTextNode("Hi there and greetings!");

//   // add the text node to the newly created div
//   newDiv.appendChild(newContent);

//   // add the newly created element and its content into the DOM
//   const currentDiv = document.getElementById("myP");
//   document.body.insertBefore(newDiv, currentDiv);
// }

/*
Events are actions or occurrences that happen in the system you are 
programming, which the system tells you about so your code can react to them.

In the case of the Web, events are fired inside the browser window, 
and tend to be attached to a specific item that resides in it. 
This might be a single element, a set of elements, the HTML document 
loaded in the current tab, or the entire browser window. 
There are many different types of events that can occur.

For example:

The user selects a certain element or hovers the cursor over a certain element.
The user chooses a key on the keyboard.
The user resizes or closes the browser window.
A web page finishes loading.
A form is submitted.
A video is played, paused, or finishes.
An error occurs.

*/


const btn = document.querySelector(`button`);

function random(number){
  return Math.floor(Math.random() * (number+1));
}

// btn.addEventListener(`click`, () => {
//   const rndCol = `rgb(${random(255)}, ${random(255)}, ${random(255)})`;
//   document.body.style.backgroundColor = rndCol;
// })

/*
In this code, we store a reference to the <button> element 
inside a constant called btn, using the Document.querySelector() 
function.

We also define a function that returns a random number.

The third part of the code is where we define and register the
 event handler. The <button> element has an event called 'click' 
 that fires when the user clicks the button. 
 Objects that can fire events have an addEventListener() method, 
 that takes at least two arguments: the name of the event and a 
 function to handle the event. So we call the button's 
 addEventListener() method, passing in:

the string 'click', to indicate that we want to listen to the 
click event
a function to call when the event happens. 
In our case the function generates a random RGB color and sets 
the page <body> background-color equal to that color.

*/

//it is fine to make the hander function a separarte named
//function

function changeBackground(){
  const rndCol = `rgb(${random(255)}, ${random(255)}, ${random(255)})`;
  document.body.style.backgroundColor = rndCol;
}
// btn.addEventListener(`click`, changeBackground);

/*
Objects (such as buttons) that can fire events also usually 
have properties whose name is on followed by the name of the event. 
For example, elements have a property onclick. 
This is called an event handler property. 
To listen for the event, you can assign the handler function 
to the property. */

btn.onclick = changeBackground;

/*
Keyboard Events
Web browsers also track when visitors use their keyboards, 
so you can assign com- mands to keys or let your visitors control
a script by pressing various keys. For example, pressing the space 
bar could start and stop a JavaScript animation.
Unfortunately, the different browsers handle keyboard events 
differently, even mak- ing it hard to tell which letter was entered! 

• keypress. The moment you press a key, the keypress event fires. 
 You don’t have to let go of the key, either. 
 In fact, the keypress event continues to fire, over and over again, 
 as long as you hold the key down.
• keydown. The keydown event is like the keypress event—it’s fired 
  when you press a key. Actually, it’s fired right before the 
  keypress event. In Firefox and Opera, the keydown event only fires once. 
  In Internet Explorer and Safari, the keydown event behaves just like 
  the keypress event—it fires over and over as long as the key is pressed.
• keyup. Finally, the keyup event is triggered when you release a key.
 */